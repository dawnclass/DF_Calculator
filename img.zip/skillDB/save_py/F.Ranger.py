file_name='F.Ranger'
job_name='크림슨로제'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'블레이드 댄싱',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'556200',
         'talisman':True
         },
        {'skillname':'이동사격',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'683283',
         'talisman':False
         },
        {'skillname':'멀티 헤드샷',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'423872',
         'talisman':False
         },
        {'skillname':'스피닝 탑 건호크',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'1967711',
         'talisman':True
         },
        {'skillname':'블러디 카니발',
         'reqlvl':'50',
         'maxlvl':'12',
         'lvl_interval':'5',
         'damage':'1391747',
         'silmari':False
         },
        {'skillname':'블러디 스파이크',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'504814',
         'talisman':False
         },
        {'skillname':'제압 사격',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'981846',
         'talisman':False
         },
        {'skillname':'킬 포인트',
         'reqlvl':'75',
         'maxlvl':'11',
         'lvl_interval':'3',
         'damage':'714100',
         'talisman':False
         },
        {'skillname':'체인 디바이더',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'649245',
         'talisman':False
         },
        {'skillname':'블러드 앤 체인',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'5',
         'damage':'1923581',
         'silmari':True
         }
        ],
    'passive':
    [
        {'skillname':'리볼버 강화',
         'reqlvl':'15',
         'up_eff':'',
         'special_synergy':None
            },
        {'skillname':'스타일리쉬',
         'reqlvl':'20',
         'up_eff':'',
         'special_synergy':None
            },
        {'skillname':'베일드 컷',
         'reqlvl':'48',
         'up_eff':'',
         'special_synergy':None
            },
        {'skillname':'쏘우 블레이드',
         'reqlvl':'75',
         'up_eff':'',
         'special_synergy':None
            },
        {'skillname':'내딛는 한걸음',
         'reqlvl':'95',
         'up_eff':'',
         'special_synergy':None
            },
        {'skillname':'찰나의 깨달음',
         'reqlvl':'95',
         'up_eff':'',
         'special_synergy':None
            }
        ]
    }
