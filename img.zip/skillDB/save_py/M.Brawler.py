file_name='M.Brawler'
job_name='명왕'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'크레이지 발칸',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'602285',
         'talisman':False,
         'synergy':{'40':'0.0164383561643835'}
         },
        {'skillname':'백스트리트 태클',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'3',
         'damage':'608056',
         'talisman':True
         },
        {'skillname':'베놈 익스플로전',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'707590',
         'talisman':True
         },
        {'skillname':'니들 스핀',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'863700',
         'talisman':False
         },
        {'skillname':'더티 배럴',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'543077',
         'talisman':False
         },
        {'skillname':'체인드라이브',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'damage':'780054',
         'talisman':False
         },
        {'skillname':'만천화우',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'722550',
         'talisman':False
         },
        {'skillname':'개조형 파진포-연화',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'2',
         'damage':'1805223',
         'talisman':False
         },
        {'skillname':'로드 투 헬',
         'reqlvl':'95',
         'maxlvl':'6',
         'lvl_interval':'2',
         'damage':'1042152',
         'talisman':False
         },
        {'skillname':'배드 엔딩',
         'reqlvl':'100',
         'maxlvl':'2',
         'lvl_interval':'5',
         'damage':'3007539',
         'talisman':False
         }
        ]
    }
