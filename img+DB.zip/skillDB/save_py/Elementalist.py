file_name='Elementalist'
job_name='오버마인드'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'플레임 스트라이크',
         'reqlvl':'15',
         'maxlvl':'46',
         'lvl_interval':'2',
         'damage':'145168',
         'talisman':None,
         'cooltime':'5.2'
         },
        {'skillname':'칠링 팬스',
         'reqlvl':'25',
         'maxlvl':'41',
         'lvl_interval':'2',
         'damage':'250880',
         'talisman':None,
         'cooltime':'11.2'
         },
        {'skillname':'썬더 스트라이크',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'484720',
         'cooltime':'15',
         'coolsynergy':None,
         'talisman':{'skillname':'썬더 엘리미네이트',
                     'damage':'618148'
                     }
         },
        {'skillname':'아크틱 피스트',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'410573',
         'talisman':None,
         'cooltime':'14.2'
         },
        {'skillname':'나이트 할로우',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'638793',
         'cooltime':'26.2',
         'talisman':{'skillname':'센트릭 유니버스',
                     'damage':'817655'
                     }
         },
        {'skillname':'핼로윈 버스터',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'711272',
         'cooltime':'33.7',
         'talisman':{'skillname':'포스 오브 오버마인드',
                     'damage':'876285'
                     }
         },
        {'skillname':'에스트럴 스톰',
         'reqlvl':'50',
         'maxlvl':'12',
         'lvl_interval':'5',
         'damage':'1556185',
         'cooltime':'145',
         'silmari':None
         },
        {'skillname':'엘레멘탈 커튼',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'544663',
         'cooltime':'22.5',
         'talisman':{'skillname':'서프레션 이펙트',
                     'damage':'698232',
                     'cooldown':'0.05'
                     }
         },
        {'skillname':'엘레멘탈 퀘이크',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'840401',
         'cooltime':'37.5',
         'talisman':{'skillname':'플레임 게이저',
                     'damage':'1037609'
                     }
         },
        {'skillname':'초월의 크리스탈',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'cooltime':'30',
         'damage':'760327',
         'talisman':None
         },
        {'skillname':'더 게이트',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'772603',
         'cooltime':'33.7',
         'talisman':None
         },
        {'skillname':'제6원소',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'5',
         'damage':'2310711',
         'cooltime':'180',
         'silmari':True
         }
        ],
    'passive':[]
    }
