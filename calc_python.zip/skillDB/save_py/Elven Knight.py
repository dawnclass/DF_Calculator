file_name='Elven Knight'
job_name='가이아'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'신록의 검',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'251681',
         'talisman':None,
         'cooltime':'10'
         },
        {'skillname':'엘비쉬 점프',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'278184',
         'talisman':None,
         'cooltime':'7.5'
         },
        {'skillname':'뱅가드 스트랏슈',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'348633',
         'cooltime':'15',
         'coolsynergy':None,
         'talisman':{'skillname':'뱅가드 스플래쉬',
                     'damage':'441159'
                     }
         },
        {'skillname':'자연의 속박',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'398062',
         'talisman':None,
         'cooltime':'15'
         },
        {'skillname':'런지 에볼루션',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'623320',
         'cooltime':'25',
         'talisman':{'skillname':'자연의 바람',
                     'damage':'730174',
                     'cooldown':'0.1'
                     }
         },
        {'skillname':'분쇄',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'847380',
         'cooltime':'45',
         'talisman':{'skillname':'뉴트럴 헌팅',
                     'damage':'1021348'
                     }
         },
        {'skillname':'천마 섬광',
         'reqlvl':'50',
         'maxlvl':'12',
         'lvl_interval':'5',
         'damage':'1387372',
         'cooltime':'145',
         'silmari':None
         },
        {'skillname':'생명의 전조',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'623497',
         'cooltime':'30',
         'talisman':{'skillname':'생명의 온기',
                     'damage':'673377'
                     }
         },
        {'skillname':'신뢰의 돌파',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'914844',
         'cooltime':'50',
         'talisman':{'skillname':'에이션트 유니언',
                     'damage':'1117027'
                     }
         },
        {'skillname':'체인 스트라이크',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'cooltime':'40',
         'damage':'948595',
         'talisman':None
         },
        {'skillname':'자연의 분노',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'797801',
         'cooltime':'45',
         'talisman':None
         },
        {'skillname':'트와일라잇 유니콘',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'5',
         'damage':'2094605',
         'cooltime':'180',
         'silmari':True
         }
        ],
    'passive':[]
    }
