file_name='Dark Knight'
job_name='다크나이트'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'다크 레이브',
         'reqlvl':'25',
         'maxlvl':'41',
         'lvl_interval':'2',
         'damage':'824719',
         'talisman':None,
         'cooltime':'30',
         'synergy':{'대검':'0.0354',
                    '둔기':'0.0354',
                    '광검':'0.0354'}
         },
        {'skillname':'다크 폴',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'468457',
         'cooltime':'20',
         'talisman':{'skillname':'다크 데몰리션',
                     'damage':'534041',
                     'cooldown':'0.1'
                     },
         'synergy':{'대검':'-0.1029',
                    '둔기':'-0.1029',
                    '광검':'-0.1029'}
         },
        {'skillname':'다크 소드',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'468222',
         'talisman':None,
         'cooltime':'20',
         'synergy':{'대검':'0.0354',
                    '둔기':'0.0354',
                    '광검':'0.0354'}
         },
        {'skillname':'다크 플레임 소드',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'965108',
         'cooltime':'45',
         'talisman':{'skillname':'다크 블리스터링 소드',
                     'damage':'1233288'
                     }
         },
        {'skillname':'다크 브레이크',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'848038',
         'cooltime':'40',
         'talisman':None
         },
        {'skillname':'웨이브 스핀',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'743966',
         'cooltime':'45',
         'talisman':None
         },
        {'skillname':'일루젼 슬래쉬',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'829514',
         'cooltime':'45',
         'talisman':{'skillname':'언리미티드 콤보',
                     'damage':'1079191'
                     }
         },
        {'skillname':'팬텀 소드',
         'reqlvl':'50',
         'maxlvl':'19',
         'lvl_interval':'3',
         'damage':'522290',
         'cooltime':'45',
         'silmari':None
         },
        {'skillname':'다크 웨이브 폴',
         'reqlvl':'60',
         'maxlvl':'16',
         'lvl_interval':'3',
         'cooltime':'30',
         'damage':'808391',
         'talisman':{'skillname':'다크 리버레이션',
                     'damage':'970069',
                     'cooldown':'0.1'
                     }
         },
        {'skillname':'차지 익스플로전',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'781801',
         'cooltime':'45',
         'talisman':{'skillname':'모멘트 익스플로전',
                     'damage':'1038578',
                     'cooldown':'0.1'
                     }
         },
        {'skillname':'다크 버스트',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'957076',
         'cooltime':'50',
         'talisman':None
         },
        {'skillname':'타임 브레이크',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'5',
         'damage':'2017880',
         'cooltime':'180',
         'silmari':True
         }
        ],
    'passive':[]
    }
