file_name='Blade Master'
job_name='검신'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'류심 승',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'316135',
         'talisman':None,
         'cooltime':'9',
         'synergy':{'대검':'-0.123839',
                    '둔기':'-0.123839',
                    '소검':'-0.123839',
                    '도':'0.006623839'}
         },
        {'skillname':'발도',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'374591',
         'talisman':{'skillname':'명가의 손놀림',
                     'damage':'471985',
                     },
         'cooltime':'15',
         'synergy':{'소검':'0.07692727769',
                    '도':'-0.0384454355'}
         },
        {'skillname':'맹룡단공참',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'459816',
         'cooltime':'20',
         'coolsynergy':None,
         'talisman':{'skillname':'맹룡선풍참',
                     'damage':'601809',
                     },
         'synergy':{'소검':'0.25',
                    "12130": "0.2318064"}
         },
        {'skillname':'차지버스트',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'548913',
         'talisman':None,
         'cooltime':'25'
         },
        {'skillname':'환영검무',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'927900',
         'cooltime':'45',
         'talisman':{'skillname':'그림자 유희',
                     'damage':'1198499'
                     },
         'synergy':{'둔기':'0.02462258',
                    '소검':'0.0694663395',
                    "11130": "0.21588129",
		    "11131": "0.21588129"}
         },
        {'skillname':'극 귀검술-유성락',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'794385',
         'cooltime':'35',
         'talisman':{'skillname':'유성의 심판',
                     'damage':'1035932'
                     }
         },
        {'skillname':'극초발도',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'894082',
         'cooltime':'50',
         'talisman':{'skillname':'쾌속발도',
                     'damage':'992431',
                     'cooldown':'0.1'
                     }
         },
        {'skillname':'극 귀검술-심검',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'damage':'785353',
         'cooltime':'35',
         'talisman':None,
         'synergy':{'대검':'-0.001',
                    '둔기':'-0.075',
                    '소검':'-0.075'}
         },
        {'skillname':'극 발검술-섬단',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'933618',
         'cooltime':'50',
         'talisman':None
         },
        {'skillname':'이기어검술',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'5',
         'cooltime':'180',
         'damage':'1314602',
         'talisman':None
         },
        {'skillname':'극 발검술-무형참',
         'reqlvl':'95',
         'maxlvl':'6',
         'lvl_interval':'2',
         'damage':'989231',
         'cooltime':'60',
         'talisman':None
         },
        {'skillname':'천제극섬',
         'reqlvl':'100',
         'maxlvl':'2',
         'lvl_interval':'5',
         'damage':'2818820',
         'cooltime':'290',
         'silmari':None
         }
        ],
    'passive':[]
    }
