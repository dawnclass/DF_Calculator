file_name='Battle Mage'
job_name='아슈타르테'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'타이머 밤',
         'reqlvl':'25',
         'maxlvl':'41',
         'lvl_interval':'2',
         'damage':'377249',
         'talisman':None,
         'cooltime':'12'
         },
        {'skillname':'쇄패',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'231330',
         'talisman':None,
         'cooltime':'8',
         'synergy':{"111038": "0.5"}
         },
        {'skillname':'체이서 프레스',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'525230',
         'cooltime':'25',
         'coolsynergy':None,
         'talisman':{'skillname':'언리밋 프레스',
                     'damage':'652335',
                     }
         },
        {'skillname':'뇌연격',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'466759',
         'talisman':None,
         'cooltime':'20'
         },
        {'skillname':'강습유성타',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'504647',
         'cooltime':'25',
         'talisman':{'skillname':'패황유성권',
                     'damage':'598763'
                     }
         },
        {'skillname':'황룡천공',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'912248',
         'cooltime':'45',
         'talisman':{'skillname':'황룡유희',
                     'damage':'1131182'
                     }
         },
        {'skillname':'퀘이사 익스플로전',
         'reqlvl':'50',
         'maxlvl':'12',
         'lvl_interval':'5',
         'damage':'1754162',
         'cooltime':'145',
         'silmari':True
         },
        {'skillname':'트윙클 스매쉬',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'597052',
         'cooltime':'30',
         'talisman':{'skillname':'홈런 퀸',
                     'damage':'686610'
                     }
         },
        {'skillname':'진-뇌연격',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'902346',
         'cooltime':'50',
         'talisman':{'skillname':'뇌신연격',
                     'damage':'1042200'
                     }
         },
        {'skillname':'체이서 클러스터',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'cooltime':'45',
         'damage':'763743',
         'talisman':None
         },
        {'skillname':'사도의 춤',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'704395',
         'cooltime':'40',
         'talisman':None
         },
        {'skillname':'일기당천',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'5',
         'damage':'1313512',
         'cooltime':'180',
         'silmari':None
         }
        ],
    'passive':[]
    }
