file_name='Berserker'
job_name='블러드이블'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'레이징 퓨리',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'338288',
         'talisman':None,
         'cooltime':'12.8',
         'synergy':None
         },
        {'skillname':'블러디 레이브',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'666298',
         'talisman':None,
         'cooltime':'24',
         'synergy':None
         },
        {'skillname':'격노',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'565896',
         'cooltime':'20',
         'coolsynergy':None,
         'talisman':{'skillname':'광전사의 분노',
                     'damage':'702274',
                     'cooldown':'0.1'
                     },
         'synergy':None
         },
        {'skillname':'블러드 소드',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'479276',
         'talisman':{'skillname':'멈추지 않는 갈증',
                     'damage':'613473'
                     },
         'cooltime':'16'
         },
        {'skillname':'아웃레이지 브레이크',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'767036',
         'cooltime':'32',
         'talisman':{'skillname':'블러드 퀘이크',
                     'damage':'905102',
                     'cooldown':'0.05'
                     },
         'synergy':None
         },
        {'skillname':'블러드 스내치',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'689244',
         'cooltime':'30',
         'talisman':{'skillname':'포스 오브 블러드',
                     'damage':'827093'
                     }
         },
        {'skillname':'버스트 퓨리',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'1119814',
         'cooltime':'50',
         'talisman':{'skillname':'피의 소용돌이',
                     'damage':'1310182',
                     'cooldown':'0.05'
                     }
         },
        {'skillname':'블러드 붐',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'damage':'977400',
         'cooltime':'40',
         'talisman':None,
         'synergy':None
         },
        {'skillname':'페이탈 블러드',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'1078609',
         'cooltime':'45',
         'talisman':None
         },
        {'skillname':'블러드 리븐',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'5',
         'cooltime':'180',
         'damage':'1763195',
         'talisman':None
         },
        {'skillname':'램펀트 매드니스',
         'reqlvl':'95',
         'maxlvl':'6',
         'lvl_interval':'2',
         'damage':'1206935',
         'cooltime':'60',
         'talisman':None
         },
        {'skillname':'혈귀극도-파멸',
         'reqlvl':'100',
         'maxlvl':'2',
         'lvl_interval':'5',
         'damage':'3247328',
         'cooltime':'290',
         'silmari':None
         }
        ],
    'passive':[]
    }
