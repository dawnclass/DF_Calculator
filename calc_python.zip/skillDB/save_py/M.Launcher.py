file_name='M.Launcher'
job_name='디스트로이어'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'레이저 라이플',
         'reqlvl':'25',
         'maxlvl':'42',
         'lvl_interval':'2',
         'damage':'207049',
         'talisman':None,
         'cooltime':'7',
         'synergy':{'25':'0.0333333333333334',
                    '111030':'0.2'
                    }
         },
        {'skillname':'스팅어',
         'reqlvl':'35',
         'maxlvl':'37',
         'lvl_interval':'2',
         'damage':'423906',
         'talisman':None,
         'cooltime':'20',
         'synergy':None
         },
        {'skillname':'그레네이드 런처',
         'reqlvl':'35',
         'maxlvl':'37',
         'lvl_interval':'2',
         'damage':'292895',
         'cooltime':'15',
         'talisman':{'skillname':'디 오버워크',
                     'damage':'351475'
                     }
         },
        {'skillname':'양자 폭탄',
         'reqlvl':'40',
         'maxlvl':'34',
         'lvl_interval':'2',
         'damage':'436893',
         'cooltime':'18',
         'talisman':{'skillname':'콜 더 퀸텀 스톰',
                     'damage':'557827'
                     }
         },
        {'skillname':'X-1 익스트루더',
         'reqlvl':'45',
         'maxlvl':'32',
         'lvl_interval':'2',
         'damage':'891711',
         'cooltime':'45',
         'talisman':{'skillname':'더 서클 아웃버스트',
                     'damage':'1068626'
                     }
         },
        {'skillname':'플라즈마 부스터',
         'reqlvl':'60',
         'maxlvl':'24',
         'lvl_interval':'2',
         'damage':'609721',
         'cooltime':'30',
         'talisman':{'skillname':'에드 온 레이저',
                     'damage':'707277',
                     'cooldown':'0.12'
                     }
         },
        {'skillname':'스팅어 SW',
         'reqlvl':'70',
         'maxlvl':'19',
         'lvl_interval':'2',
         'damage':'979573',
         'cooltime':'50',
         'talisman':{'skillname':'스커드 익스플로전',
                     'damage':'1204875'
                     }
         },
        {'skillname':'사이즈믹 웨이브',
         'reqlvl':'75',
         'maxlvl':'17',
         'lvl_interval':'2',
         'damage':'796586',
         'cooltime':'40',
         'talisman':None
         },
        {'skillname':'MSC-7',
         'reqlvl':'80',
         'maxlvl':'14',
         'lvl_interval':'2',
         'damage':'824311',
         'cooltime':'40',
         'talisman':None
         },
        {'skillname':'버스터 빔',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'2',
         'damage':'1917967',
         'cooltime':'180',
         'talisman':None
         },
        {'skillname':'MLDRS-95',
         'reqlvl':'95',
         'maxlvl':'7',
         'lvl_interval':'2',
         'damage':'1115956',
         'cooltime':'60',
         'talisman':None
         },
        {'skillname':'오비탈 디재스터',
         'reqlvl':'100',
         'maxlvl':'2',
         'lvl_interval':'5',
         'damage':'3584238',
         'cooltime':'290',
         'silmari':None
         }
        ],
    'passive':[]
    }
