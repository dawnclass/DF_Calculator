file_name='Vanguard'
job_name='워로드'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'임팩트 스매쉬',
         'reqlvl':'25',
         'maxlvl':'20',
         'lvl_interval':'3',
         'damage':'91744',
         'talisman':None,
         'cooltime':'3'
         },
        {'skillname':'크레센트 슬래쉬',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'216179',
         'talisman':None,
         'cooltime':'7'
         },
        {'skillname':'드레드보어',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'402000',
         'cooltime':'16',
         'coolsynergy':None,
         'talisman':{'skillname':'나선마환창',
                     'damage':'482400'
                     }
         },
        {'skillname':'비헤드',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'332358',
         'talisman':None,
         'cooltime':'14'
         },
        {'skillname':'블레이드 스톰',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'434582',
         'cooltime':'18',
         'talisman':{'skillname':'광풍마창',
                     'damage':'551915'
                     }
         },
        {'skillname':'디베스테이트',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'788136',
         'cooltime':'40',
         'talisman':{'skillname':'사이클론 데모닉 스피어',
                     'damage':'992028'
                     }
         },
        {'skillname':'유 다이드',
         'reqlvl':'50',
         'maxlvl':'12',
         'lvl_interval':'5',
         'damage':'1294509',
         'cooltime':'145',
         'silmari':None
         },
        {'skillname':'런지 스트라이크',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'602045',
         'cooltime':'25',
         'talisman':{'skillname':'파워 스트라이크',
                     'damage':'741730',
                     'cooldown':'0.1'
                     }
         },
        {'skillname':'둠 글레이브',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'951142',
         'cooltime':'50',
         'talisman':{'skillname':'둠 슬래쉬',
                     'damage':'1160394'
                     }
         },
        {'skillname':'데들리 매서커',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'cooltime':'40',
         'damage':'782661',
         'talisman':None
         },
        {'skillname':'버스트 슬래쉬',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'774207',
         'cooltime':'45',
         'talisman':None
         },
        {'skillname':'데모닉 인페르노',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'5',
         'damage':'2034201',
         'cooltime':'180',
         'silmari':True
         }
        ],
    'passive':[]
    }
