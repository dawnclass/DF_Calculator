file_name='M.Ranger'
job_name='레이븐'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'트리플 탭',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'280878',
         'talisman':None,
         'cooltime':'8',
         'synergy':None
         },
        {'skillname':'이동사격',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'686328',
         'talisman':None,
         'cooltime':'24.3',
         'synergy':None
         },
        {'skillname':'난사',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'499046',
         'cooltime':'17.6',
         'talisman':{'skillname':'엑셀레이션 리볼버',
                     'damage':'625804'
                     }
         },
        {'skillname':'멀티 헤드샷',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'487557',
         'cooltime':'19.8',
         'talisman':{'skillname':'와이드 아웃',
                     'damage':'594820'
                     }
         },
        {'skillname':'더블 건호크',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'1456090',
         'cooltime':'44.6',
         'talisman':{'skillname':'더블 그라인더',
                     'damage':'1698219'
                     }
         },
        {'skillname':'데들리 어프로치',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'727788',
         'cooltime':'30',
         'talisman':{'skillname':'먹이사냥',
                     'damage':'887902',
                     'cooldown':'0.1'
                     }
         },
        {'skillname':'제압 사격',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'1035626',
         'cooltime':'50',
         'talisman':{'skillname':'매거진 핸들링',
                     'damage':'1275893'
                     }
         },
        {'skillname':'패스트 드로우',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'damage':'1040657',
         'cooltime':'40'
         },
        {'skillname':'와이프 아웃',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'858105',
         'cooltime':'45'
         },
        {'skillname':'세븐스 플로우',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'2',
         'damage':'1772115',
         'cooltime':'180',
         'talisman':None
         },
        {'skillname':'엑셀레이션 트리거',
         'reqlvl':'95',
         'maxlvl':'6',
         'lvl_interval':'2',
         'damage':'1163400',
         'cooltime':'60',
         'talisman':None
         },
        {'skillname':'데스 크라이시스',
         'reqlvl':'100',
         'maxlvl':'2',
         'lvl_interval':'5',
         'damage':'3238184',
         'cooltime':'290',
         'silmari':None
         }
        ],
    'passive':[]
    }
