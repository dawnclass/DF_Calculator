file_name='M.Brawler'
job_name='명왕'

info={
    'common':
    {
        'common_damage':'34184',
        'common_ele':'447'
        
        },
    'skill':
    [
        {'skillname':'바늘 투척',
         'reqlvl':'25',
         'maxlvl':'41',
         'lvl_interval':'2',
         'damage':'104088',
         'talisman':None,
         'cooltime':'2.1',
         'synergy':None
         },
        {'skillname':'크레이지 발칸',
         'reqlvl':'30',
         'maxlvl':'38',
         'lvl_interval':'2',
         'damage':'602285',
         'talisman':None,
         'cooltime':'15',
         'synergy':{'40':'0.0164383561643835',
                    '12130':'-0.3',
                    '14130':'0.42857'}
         },
        {'skillname':'그라운드 태클',
         'reqlvl':'35',
         'maxlvl':'36',
         'lvl_interval':'2',
         'damage':'503914',
         'cooltime':'20',
         'talisman':{'skillname':'백스트리트 태클',
                     'damage':'608056',
                     'cooldown':'0.1'
                     }
         },
        {'skillname':'베놈 마인',
         'reqlvl':'40',
         'maxlvl':'33',
         'lvl_interval':'2',
         'damage':'562151',
         'cooltime':'24',
         'talisman':{'skillname':'베놈 익스플로전',
                     'damage':'707590'
                     }
         },
        {'skillname':'니들 스핀',
         'reqlvl':'45',
         'maxlvl':'31',
         'lvl_interval':'2',
         'damage':'863700',
         'cooltime':'45',
         'talisman':{'skillname':'니들 스톰',
                     'damage':'1035576'
                     }
         },
        {'skillname':'더티 배럴',
         'reqlvl':'60',
         'maxlvl':'23',
         'lvl_interval':'2',
         'damage':'543077',
         'cooltime':'20',
         'talisman':{'skillname':'킥 애스',
                     'damage':'589334'
                     }
         },
        {'skillname':'광폭혈쇄',
         'reqlvl':'70',
         'maxlvl':'18',
         'lvl_interval':'2',
         'damage':'787916',
         'cooltime':'50',
         'talisman':{'skillname':'스카페이스',
                     'damage':'945499',
                     'cooldown':'0.09'
                     }
         },
        {'skillname':'체인드라이브',
         'reqlvl':'75',
         'maxlvl':'16',
         'lvl_interval':'2',
         'damage':'780054',
         'cooltime':'40',
         'talisman':None
         },
        {'skillname':'만천화우',
         'reqlvl':'80',
         'maxlvl':'13',
         'lvl_interval':'2',
         'damage':'722550',
         'cooltime':'45',
         'talisman':None
         },
        {'skillname':'개조형 파진포-연화',
         'reqlvl':'85',
         'maxlvl':'5',
         'lvl_interval':'2',
         'damage':'1805223',
         'cooltime':'180',
         'talisman':None
         },
        {'skillname':'로드 투 헬',
         'reqlvl':'95',
         'maxlvl':'6',
         'lvl_interval':'2',
         'damage':'1042152',
         'cooltime':'60',
         'talisman':None
         },
        {'skillname':'배드 엔딩',
         'reqlvl':'100',
         'maxlvl':'2',
         'lvl_interval':'5',
         'damage':'3007539',
         'cooltime':'290',
         'silmari':None
         }
        ],
    'passive':[]
    }
